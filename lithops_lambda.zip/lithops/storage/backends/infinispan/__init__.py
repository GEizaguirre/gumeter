from .infinispan import InfinispanBackend as StorageBackend

__all__ = ['StorageBackend']
