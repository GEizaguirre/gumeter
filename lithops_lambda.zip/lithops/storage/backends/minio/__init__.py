from .minio import MinioStorageBackend as StorageBackend

__all__ = ['StorageBackend']
