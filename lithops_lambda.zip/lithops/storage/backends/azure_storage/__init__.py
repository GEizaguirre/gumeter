from .azure_storage import AzureBlobStorageBackend as StorageBackend

__all__ = ['StorageBackend']
