from .redis import RedisBackend as StorageBackend

__all__ = ['StorageBackend']
