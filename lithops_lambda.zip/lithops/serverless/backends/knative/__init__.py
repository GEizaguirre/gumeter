from .knative import KnativeServingBackend as ServerlessBackend

__all__ = ['ServerlessBackend']
