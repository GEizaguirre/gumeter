from .k8s import KubernetesBackend as ServerlessBackend

__all__ = ['ServerlessBackend']
