from .singularity import SingularityBackend as ServerlessBackend

__all__ = ['ServerlessBackend']
