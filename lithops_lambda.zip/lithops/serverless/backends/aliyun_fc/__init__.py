from .aliyun_fc import AliyunFunctionComputeBackend as ServerlessBackend

__all__ = ['ServerlessBackend']
