from .vm import VMBackend as StandaloneBackend

__all__ = ['StandaloneBackend']
