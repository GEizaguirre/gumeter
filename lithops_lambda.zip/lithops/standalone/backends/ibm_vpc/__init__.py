from .ibm_vpc import IBMVPCBackend as StandaloneBackend

__all__ = ['StandaloneBackend']
