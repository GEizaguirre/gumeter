from .azure_vms import AzureVMSBackend as StandaloneBackend

__all__ = ['StandaloneBackend']
